# Startup

  node search.js

Browse to [http://localhost:7777/](http://localhost:7777/)
